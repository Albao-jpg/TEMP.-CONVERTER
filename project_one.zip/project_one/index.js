const tempInput = document.getElementById('temp');
const unitSelect = document.getElementById('unit');
const celsiusResult = document.getElementById('celsius');
const fahrenheitResult = document.getElementById('fahrenheit');
const kelvinResult = document.getElementById('kelvin');
const resetButton = document.getElementById('reset');

function convertTemperature() {
    const temp = parseFloat(tempInput.value);
    const unit = unitSelect.value;

    let celsius, fahrenheit, kelvin;

    if (unit === 'celsius') {
        celsius = temp;
        fahrenheit = (temp * 9/5) + 32;
        kelvin = temp + 273.15;
    } else if (unit === 'fahrenheit') {
        celsius = (temp - 32) * 5/9;
        fahrenheit = temp;
        kelvin = (temp + 459.67) * 5/9;
    } else if (unit === 'kelvin') {
        celsius = temp - 273.15;
        fahrenheit = (temp * 9/5) - 459.67;
        kelvin = temp;
    }

    celsiusResult.textContent = celsius.toFixed(2) + ' °C';
    fahrenheitResult.textContent = fahrenheit.toFixed(2) + ' °F';
    kelvinResult.textContent = kelvin.toFixed(2) + ' K';
}

tempInput.addEventListener('input', convertTemperature);
unitSelect.addEventListener('change', convertTemperature);

resetButton.addEventListener('click', () => {
    tempInput.value = '';
    unitSelect.value = 'celsius';
    celsiusResult.textContent = '';
    fahrenheitResult.textContent = '';
    kelvinResult.textContent = '';
});